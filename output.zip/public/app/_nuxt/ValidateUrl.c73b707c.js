function r(t){var a=/^(?:(?:https?):\/\/)?(?:www\.)?([a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,})(?:\/[^\s]*)?$/i;return a.test(t)}export{r as V};
