import{a6 as p,a0 as o,a7 as a}from"./entry.e6451b68.js";const i={},f=p(i);function s(){const n=o();return n._appConfig||(n._appConfig=a(f)),n._appConfig}export{s as u};
