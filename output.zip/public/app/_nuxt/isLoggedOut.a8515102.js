import{a1 as a,D as o,a2 as s,a3 as n}from"./entry.31e86c9c.js";const g=a(async(u,c)=>{let e,t;const r=o();try{[e,t]=s(()=>r.getUser()),await e,t()}catch{return n("/login")}});export{g as default};
