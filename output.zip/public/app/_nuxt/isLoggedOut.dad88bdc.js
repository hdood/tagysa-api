import{a1 as a,D as o,a2 as s,a3 as n}from"./entry.e6451b68.js";const g=a(async(u,c)=>{let e,t;const r=o();try{[e,t]=s(()=>r.getUser()),await e,t()}catch{return n("/login")}});export{g as default};
